#JSGames

##Solitaire
###Object
Clicking a square toggles it blue, as well as its neighbours
 in all directions. The game begins with a blue center square.
  The game is over when you have successfully turned all the
   squares blue.

###Background
Solitare was built using the bootstrap framework and jQuery.

With the exception of the header, all html elements on the
 page are added using jQuery.

A resilient onClick handler is used to bind clicks to all squares at once.

##Mastermind
###Object
Guess the five digit secret code in twenty guesses or fewer.

###Background
Mastermind is adapted from Codebreaker, an RSpec teaching tool. It is expanded and modified to include ruby, javascript, sinatra, and bootstrap




