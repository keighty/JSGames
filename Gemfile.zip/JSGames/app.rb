require 'rubygems'
require 'sinatra'
require 'sinatra/activerecord'
require 'sinatra/base'
require './lib/mastermind'

set :database, "sqlite3:///mastermind.db"

class TopPlayer < ActiveRecord::Base
end

class JSGames < Sinatra::Base
  get '/' do
    erb :index
  end

  get '/solitaire' do
    erb :solitaire
  end

  get '/mastermind' do
    erb :mastermind
  end

  post '/game/:guess' do
    game.guess(params[:guess])
  end

  not_found do
    halt 404, 'page not found'
  end

  private
    def game
      @game ||= Mastermind::Game.new_with_code(params[:code])
    end
end

# curl -X POST -H "Accept: application/json" -d "code=12345" localhost:9393/game/12345